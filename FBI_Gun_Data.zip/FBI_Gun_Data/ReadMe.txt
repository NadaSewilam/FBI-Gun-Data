to understand the dataset:
https://www.fbi.gov/file-repository/nics_firearm_checks_-_month_year_by_state_type.pdf/view


grouby operations:
http://net-informations.com/ds/pda/gby.htm 


to delete/drop columns:
https://www.kite.com/python/answers/how-to-delete-columns-from-a-pandas-%60dataframe%60-by-index-in-python

https://thispointer.com/drop-first-row-of-pandas-dataframe-3-ways/


transpose:
https://note.nkmk.me/en/python-pandas-t-transpose/

transferring list to a new dataframe:
https://www.geeksforgeeks.org/different-ways-to-create-pandas-dataframe/

to draw line chart:
https://pythontic.com/pandas/dataframe-plotting/line%20chart


to count NaN values in dataframe:
https://datatofish.com/count-nan-pandas-dataframe/


to plot a horizontal bar:
https://pandas.pydata.org/docs/reference/api/pandas.DataFrame.plot.barh.html


to create a method:
https://stackoverflow.com/questions/3786881/what-is-a-method-in-python

